function visible(el){const r=el.getBoundingClientRect();const s=getComputedStyle(el);return r.width>0&&r.height>0&&s.visibility!=='hidden'&&s.display!=='none';}
function norm(v){return String(v||'').replace(/\s+/g,' ').trim().toLowerCase();}
function setValue(el,value){if(!el||value===undefined||value===null||String(value)==='')return false;const proto=el instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;const d=Object.getOwnPropertyDescriptor(proto,'value');if(d?.set)d.set.call(el,String(value));else el.value=String(value);['input','change','blur'].forEach(t=>el.dispatchEvent(new Event(t,{bubbles:true})));return true;}
function textFor(el){const bits=[el.getAttribute('aria-label'),el.getAttribute('placeholder'),el.name,el.id];if(el.id){const l=document.querySelector(`label[for="${CSS.escape(el.id)}"]`);if(l)bits.push(l.textContent);}const p=el.closest('label');if(p)bits.push(p.textContent);const wrap=el.parentElement?.parentElement;if(wrap)bits.push(wrap.textContent?.slice(0,180));return norm(bits.filter(Boolean).join(' '));}
function findInput(keys,types=['text','number','search','tel']){return [...document.querySelectorAll('input,textarea')].filter(visible).find(el=>{const t=(el.type||'text').toLowerCase();return (el.tagName==='TEXTAREA'||types.includes(t))&&keys.some(k=>textFor(el).includes(norm(k)));});}
function findSelect(keys){return [...document.querySelectorAll('select')].filter(visible).find(el=>keys.some(k=>textFor(el).includes(norm(k))));}
function setSelect(el,wanted){if(!el||wanted===undefined||wanted===null||String(wanted)==='')return false;const option=[...el.options].find(o=>norm(o.textContent)===norm(wanted)||norm(o.textContent).includes(norm(wanted)));if(!option)return false;el.value=option.value;el.dispatchEvent(new Event('change',{bubbles:true}));return true;}
function findEditable(keys){return [...document.querySelectorAll('[contenteditable="true"],textarea')].filter(visible).find(el=>keys.some(k=>textFor(el).includes(norm(k)))||keys.some(k=>norm(el.parentElement?.textContent).includes(norm(k))));}
function setEditable(el,value){if(!el||value===undefined||value===null||String(value)==='')return false;if(el.tagName==='TEXTAREA')return setValue(el,value);el.focus();el.textContent=String(value);el.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:String(value)}));el.dispatchEvent(new Event('change',{bubbles:true}));return true;}
function postalFromWarehouse(w){if(w?.postalCode)return String(w.postalCode);if(String(w?.countryCode||'').toUpperCase()==='CN'){const m=String(w?.address1||'').match(/\b\d{6}\b/);if(m)return m[0];}return '';}
function fillDraft(listing,control){const p=listing.product;const o=listing.offer;const s=p.itemSpecifics||{};const result={filled:[],missing:[]};const tasks=[
['title',()=>setValue(findInput(['title']),p.title)],
['price',()=>setValue(findInput(['buy it now price','price']),o.price)],
['quantity',()=>setValue(findInput(['quantity','qty']),o.quantity)],
['brand',()=>setValue(findInput(['brand']),p.brand)],
['type',()=>setValue(findInput(['type']),s.Type)],
['suitableFor',()=>setValue(findInput(['suitable for']),s['Suitable For'])],
['powerType',()=>setValue(findInput(['power type']),s['Power Type'])],
['material',()=>setValue(findInput(['material']),s.Material)],
['color',()=>setValue(findInput(['color','colour']),s.Color)],
['countryOfOrigin',()=>setValue(findInput(['country of origin']),s['Country of Origin'])||setSelect(findSelect(['country of origin']),s['Country of Origin'])],
['voltage',()=>setValue(findInput(['voltage']),s.Voltage)],
['capacity',()=>setValue(findInput(['capacity']),s.Capacity)],
['handlingTime',()=>setValue(findInput(['handling time','handling days']),o.handlingDays)],
['description',()=>setEditable(findEditable(['description']),p.description)],
['condition',()=>setSelect(findSelect(['condition']),p.condition)]
];
const w=control?.cj?.warehouse;if(control?.gates?.dispatchLocationVerified&&w){const postal=postalFromWarehouse(w);tasks.push(['postalCode',()=>setValue(findInput(['postal code','zip code','zip']),postal)]);tasks.push(['city',()=>setValue(findInput(['item location','city']),w.city)]);tasks.push(['region',()=>setValue(findInput(['state','province','region']),w.province)]);tasks.push(['country',()=>setValue(findInput(['item country','country']),w.countryCode)||setSelect(findSelect(['item country','country']),w.countryCode==='CN'?'China':w.countryCode)]);}
for(const [name,fn] of tasks){try{(fn()?result.filled:result.missing).push(name);}catch{result.missing.push(name);}}return result;}
chrome.runtime.onMessage.addListener((message,_sender,sendResponse)=>{if(message?.type==='PRISMBAY_FILL'){const r=fillDraft(message.listing,message.control);sendResponse({ok:true,message:`Draft filled: ${r.filled.join(', ')||'none'}. Review eBay category, shipping, item location, returns and payment settings before using eBay's own final List button.${r.missing.length?` Fields still requiring eBay UI selection: ${r.missing.join(', ')}.`:''}`});return true;}if(message?.type==='PRISMBAY_READY'){sendResponse({ok:true,ready:message.control?.readyForBrowserPublish===true});return true;}});
